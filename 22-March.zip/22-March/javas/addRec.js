window.onload= pageReady;
 function pageReady(){
  
     var myForm=document.forms.recpForm;
     console.log(myForm);
     var inputFood=document.getElementById("newFood");
     console.log(inputFood);
     var inputImg=document.getElementById("img");
     console.log(inputImg);
     var inputCategori=document.getElementById("catagori");
     var inputDate=document.getElementById("date");
     var inputPrep=document.getElementById("prep");
     var inputck=document.getElementById("ckTime");
     var inputRec=document.getElementById("recpText");
     var inputIng=document.getElementById("ingrid");
     var food=document.getElementById("errfood");
     var img=document.getElementById("errimg");
     var cte=document.getElementById("errcte");
     var date=document.getElementById("errdate");
     var prep=document.getElementById("errprep");
     var ckTime=document.getElementById("errckTime");
     var text=document.getElementById("errText");
     var Ing=document.getElementById("erringrid");
     myForm.onsubmit=funcRec;
      
      function funcRec(){
                 
          if (inputFood.value===""){
            inputFood.style.background="red";
            inputFood.focus();
            food.innerHTML="Please input food name";
            console.log(inputFood);
          }
          if (inputImg.value===""){
            inputImg.style.background="red";
            inputImg.focus();
            img.innerHTML="Please insert food image";
          }
          if (inputCategori.value===""){
            inputCategori.style.background="red";
           inputCategori.focus();
           cte.innerHTML="Please input a category for your food,for example:vegi";
           }
          if (inputDate.value===""){
           inputDate.style.background="red";
          inputDate.focus();
          date.innerHTML="Please input the date";
          }
          
           if (inputPrep.value===""){
            inputPrep.style.background="red";
           inputPrep.focus();
           prep.innerHTML="Please input prepare time";
           }
           if (inputck.value===""){
            inputck.style.background="red";
           inputck.focus();
           ckTime.innerHTML="Please input cook time";
           }
           if (inputRec.value===""){
            inputRec.style.background="red";
           inputRec.focus();
           text.innerHTML="Please input Recepie";
           }
           if (inputIng.value===""){
            inputIng.style.background="red";
           inputIng.focus();
           Ing.innerHTML="Please input ingridents";
           }
           
          
          return false;   
        }
}