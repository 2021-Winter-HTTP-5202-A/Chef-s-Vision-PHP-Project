window.onload= pageReady;
 function pageReady(){
  
     var formSign=document.forms.secondform;
     console.log(formSign);
     //var btnSignUp=document.getElementById("btn_signUp")
     var msgUser=document.getElementById("p-sign");
     var msgShow=document.getElementsByClassName("msg-sign");
     var inputUser=document.getElementById("userNew");
     var inputLast=document.getElementById("newLast");
     var inputMail=document.getElementById("newMail");
     var inputPass=document.getElementById("newPassword");
     var inputPasscon=document.getElementById("conPassword");
     var userErr=document.getElementById("erruserNew");
     var lastErr=document.getElementById("errnewLast");
     var mailErr=document.getElementById("ernewMail");
     var passErr=document.getElementById("ernewPassword");
     var passconErr=document.getElementById("errconPassword");
     formSign.onsubmit=funcSign;
      
      function funcSign(){
       
          if (inputUser.value===""){
            inputUser.style.background="red";
            inputUser.focus();
            userErr.innerHTML="Please input name";
          }
          if (inputLast.value===""){
            inputLast.style.background="red";
            inputLast.focus();
            lastErr.innerHTML="Please input last name";
          }
          if (inputMail.value===""){
            inputMail.style.background="red";
           inputMail.focus();
           mailErr.innerHTML="Please input Email";
           }
          if (inputPass.value===""){
           inputPass.style.background="red";
          inputPass.focus();
          passErr.innerHTML="Please input Password";
          }
          
           if (inputPasscon.value===""){
            inputPasscon.style.background="red";
           inputPasscon.focus();
           passconErr.innerHTML="Please input confirm Password";
           }
          else{
            msgUser.innerHTML="Thank you"+ inputUser.value;
            msgShow.style.display="block";
           }
          return false;   
        }
}