jQuery(document).ready(function()
{
   
    var count=1;
    //var addIngrid=document.getElementById('ingrid');
    //var newIng=document.getElementById('new');
    jQuery("#btn-ingrid").click(addNew);
    function addNew(){

        count++;
        $("#new").append('<div><input class=" form-control in-new" type="text" with="%5" name="mytext[count]"/></div>');
    }
       
    })

