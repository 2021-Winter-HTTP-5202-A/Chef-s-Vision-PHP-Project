<?php
 include 'header.php';
?>
<div class="all-div max_page">
 <h1>Login Page</h1>
 <script src="javas/log.js"></script>
          <form class="form-control" id="frm-userpass" name="myform" action="#" method="Get">
           <fieldset id="fieldset-login">
            <legend>Login User</legend>
             <div class="all-div other form-group">
                <label class="label" for="user">Email:</label>
                <input class="input form-control" type="text" id="user" name="in-email">  
              </div> 
              <div><p class="error"><span id=erUser class="errmessage"></span> <p> </div>
             <div class="all-div other form-group">
                <label class="label" for="password">password:</label>
                <input class="input form-control" type="password" id="password" name="in-pass">
             </div> 
             <div><p class="error"><span id=erPass class="errmessage"></span> <p></div>
             
           </fieldset>
           <div class="all-div form-group">
                 <input  type="submit"  name="logIn"  id="btn_logIn" class="btn-submit"   value="Log In">   
                 <a href="signUp-page.php" class="btn-submit" id="btn_sign">Sign up</a>
             </div>     
        </form>
        <div class="all-div div-message form-group">
            <p id="p-log"> </p> 
            
       </div>
      </div>
       <?php
        include 'footer.php';
        ?>
      