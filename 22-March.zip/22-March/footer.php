

<hr>
     <footer class="footer">
            <div class="page_container"> 
                <h2 class="hidden">Footer</h2>
                <nav class="nav_1">
                    <h3 class="hidden">Social Links</h3>
                    <ul class="social_links">
                        <li class="social-link"><a href="#"><i class="fas fa-envelope"></i></a></li>
                        <li class="social-link"><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li class="social-link"><a href="#"><i class="fab fa-instagram"></i></a></li>
                        <li class="social-link"><a href="#"><i class="fab fa-facebook"></i></a></li>
                    </ul>
                </nav>
                <p>Chef's Vision|<Span id="copyright">Canada &#169; 2021.<span id="rights">All rights reserved.</span></Span></p>
            </div>
        </footer>
</body>
</html>



<!--
     
-->
