
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Chef's Vision</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- styles -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/flexslider.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
    <link rel="stylesheet" href="font/css/font-awesome.min.css">
    
  </head>

  <body>
  <header>
      </header>

  
<section>
    <div class="row top-slider">
      <div class="container">
        <div class="flexslider teaser">
            <ul class="slides">
              <li>
                <div class="product-content hidden-phone slide1">
                  <h2 class="gray">We are <span class="red bold">Chef's Vision.</span> A place where anyone can share their recipes.</h2></div>
                <div class="product-img slide1"><img src="img/aboutusimg1.jpg" alt="Ingredients" /></div>
              </li>
              <li>
                <div class="product-img slide2"><img src="img/aboutusimg2.jpg" alt="Ingredients" /></div>
                <div class="product-content  hidden-phone slide2"><h2 class="red">Incredible: <span class="gray bold">Recipes</span> Perfect for <span class="bold">anyone and everyone.</span></h2>
                </div>
              </li>
            </ul>
        </div>
      </div>
    </div><!-- /top-slider -->

   
    </section>




    <!-- javascript
    ================================================== -->

    <script src="js/jquery-1.9.1.min.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
    

	
  </body>
</html>
