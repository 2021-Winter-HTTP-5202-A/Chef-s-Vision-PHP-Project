

$(document).ready(function(){
	
	// Slider teaser
	$('.flexslider.teaser').flexslider({
		animation: "slide",
		animation: "fade",
		controlNav: false
	});
});