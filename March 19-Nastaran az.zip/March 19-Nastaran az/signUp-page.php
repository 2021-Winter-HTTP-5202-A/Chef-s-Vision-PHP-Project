<?php
 include 'header.php';
 
 ?>
 <div class=max_page>
   <h1>SignUp Page</h1>
      <script src="javas/sign.js"></script>
      <form id="frm-userSignUp" class="form-control" name="secondform" action="#" method="Get">
         
          <fieldset id="fieldset-signUp">
            <legend>Register:</legend>
             <div class="all-div other form-group">
                <label class="label" for="newName">name:</label>
                <input class="input form-control"type="text" id="userNew" name="in-name">  
                <div class="all-div other"><p class="error"><span id="erruserNew" class="errmessage"></span> <p></div>
             </div> 
             <div class="all-div other form-group">
                <label for="newLast" class="label" >last name:</label>
                <input   class="input form-control" type="text" id="newLast" name="in-last">  
                <div class="all-div other"><p class="error"><span id=errnewLast class="errmessage"></span> <p></div> 
             </div> 
             <div class="all-div other form-group">
                <label class="label " for="newMail">Email:</label>
                <input  class="input form-control" type="text" id="newMail" name="in-mail">  
                <div class="all-div other" ><p class="error"><span id=ernewMail class="errmessage"></span> <p></div>
             </div> 
             <div class="all-div other form-group">
                <label class="label" for="newPassword">password:</label>
                <input  class="input form-control" type="password" id="newPassword" name="in-password">
                <div class="all-div other" ><p class="error"><span id=ernewPassword class="errmessage"></span> <p></div>
             </div> 
             <div class="all-div other form-group">
                <label class="label" for="conPassword">confirm password:</label>
                <input  class="input form-control" type="password" id="conPassword" name="in-password">
                <div class="all-div other" ><p class="error"><span id=errconPassword class="errmessage"></span> <p></div>
             </div> 
              
           </fieldset>
           <div class="all-div" id="btm_page">
                 <input  class="input btn-submit" type="submit"  name="signUp"  id="btn_signUp"   value="Sign up">
             </div>     
        </form>
        <div id="msg-sign" class="all-div div-message">
            <p id="p-sign"> </p> 
            
       </div>
     </div>
       <?php
         
         include 'footer.php';
       ?>