jQuery(document).ready(function()
{
   
    var count=1;
    //var addIngrid=document.getElementById('ingrid');
    //var newIng=document.getElementById('new');
    jQuery("#btn-ingrid").click(addNew);
    function addNew(){

        count++;
        $("#new").append('<div><input class="in-new in-recepie" type="text" name="mytext[count]"/></div>');
    }
       
    })

